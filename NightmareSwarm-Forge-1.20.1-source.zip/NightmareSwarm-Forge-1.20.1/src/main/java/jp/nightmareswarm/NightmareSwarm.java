package jp.nightmareswarm;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Husk;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Pillager;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.Vindicator;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(NightmareSwarm.MOD_ID)
public class NightmareSwarm {
    public static final String MOD_ID = "nightmareswarm";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Item> NIGHTMARE_BOSS_EGG = ITEMS.register(
            "nightmare_boss_egg", () -> new Item(new Item.Properties().stacksTo(16)));

    public NightmareSwarm() {
        // Uses vanilla mob entities, so no custom renderer or entity registration is needed.
        var modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        modBus.addListener(this::addCreativeItems);
    }

    private void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(NIGHTMARE_BOSS_EGG);
        }
    }

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class ServerEvents {
        // Intentionally intense defaults. Reduce these if the world starts lagging.
        private static final int WAVE_INTERVAL_TICKS = 100; // 5 seconds
        private static final int MAX_HOSTILES_NEAR_PLAYER = 90;
        private static final int MIN_MOBS_PER_WAVE = 8;
        private static final int EXTRA_RANDOM_MOBS = 7; // produces 8-14 mobs
        private static long tickCounter = 0;
        private static int waveCounter = 0;
        private static final Map<UUID, ServerBossEvent> BOSS_BARS = new HashMap<>();

        private static final String[] BOSS_NAMES = {
            "災厄の支配者", "深淵の破壊者", "終焉の狩人", "地獄の覇王",
            "絶望を呼ぶ者", "奈落の王", "暴虐の巨人", "終末の執行者"
        };

        @SubscribeEvent
        public static void onBossEggUse(PlayerInteractEvent.RightClickItem event) {
            if (event.getLevel().isClientSide()) return;
            if (!(event.getEntity() instanceof ServerPlayer player)) return;
            if (!event.getItemStack().is(NightmareSwarm.NIGHTMARE_BOSS_EGG.get())) return;
            if (!(player.level() instanceof ServerLevel level)) return;
            if (level.getDifficulty() == Difficulty.PEACEFUL) {
                player.displayClientMessage(Component.literal("難易度をイージー以上にしてね！")
                        .withStyle(ChatFormatting.YELLOW), true);
                return;
            }

            RandomSource random = level.getRandom();
            Vec3 look = player.getLookAngle();
            int x = player.getBlockX() + (int) Math.round(look.x * 3.0D);
            int z = player.getBlockZ() + (int) Math.round(look.z * 3.0D);
            BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    new BlockPos(x, player.getBlockY(), z));
            if (!level.getBlockState(top).isAir() || !level.getFluidState(top).isEmpty()
                    || !level.getBlockState(top.below()).blocksMotion()) {
                top = findSpawnPosition(level, player, random);
            }
            if (top == null) {
                player.displayClientMessage(Component.literal("ボスを出せる場所が見つからなかった！")
                        .withStyle(ChatFormatting.RED), true);
                return;
            }

            Monster boss = createRandomMonster(level, random);
            if (boss == null) return;
            boss.moveTo(top.getX() + 0.5D, top.getY(), top.getZ() + 0.5D,
                    random.nextFloat() * 360.0F, 0.0F);
            boss.setTarget(player);
            empowerBoss(boss, random);
            level.addFreshEntity(boss);
            player.displayClientMessage(Component.literal("NIGHTMARE SWARM：ボス召喚成功！逃げるなよ！")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
            if (!player.getAbilities().instabuild) event.getItemStack().shrink(1);
        }

        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            if (++tickCounter % WAVE_INTERVAL_TICKS != 0) return;
            waveCounter++;

            for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
                if (player.isCreative() || player.isSpectator()) continue;
                if (!(player.level() instanceof ServerLevel level)) continue;
                if (level.getDifficulty() == Difficulty.PEACEFUL) continue;

                RandomSource random = level.getRandom();
                AABB area = player.getBoundingBox().inflate(48.0, 32.0, 48.0);
                int nearbyHostiles = level.getEntitiesOfClass(Monster.class, area, Mob::isAlive).size();
                if (nearbyHostiles >= MAX_HOSTILES_NEAR_PLAYER) continue;

                int amount = MIN_MOBS_PER_WAVE + random.nextInt(EXTRA_RANDOM_MOBS);
                amount = Math.min(amount, MAX_HOSTILES_NEAR_PLAYER - nearbyHostiles);
                boolean guaranteedBossThisWave = waveCounter % 3 == 0;

                for (int i = 0; i < amount; i++) {
                    boolean boss = (guaranteedBossThisWave && i == 0) || random.nextInt(13) == 0;
                    spawnOne(level, player, random, boss);
                }
            }
        }

        private static void spawnOne(ServerLevel level, ServerPlayer player, RandomSource random, boolean boss) {
            BlockPos spawnPos = findSpawnPosition(level, player, random);
            if (spawnPos == null) return;

            Monster mob = createRandomMonster(level, random);
            if (mob == null) return;

            mob.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D,
                    random.nextFloat() * 360.0F, 0.0F);
            mob.setTarget(player);

            mob.getPersistentData().putBoolean("NightmareSwarmSpawned", true);
            if (boss) {
                empowerBoss(mob, random);
            } else if (random.nextInt(4) == 0) {
                empowerElite(mob);
            }

            level.addFreshEntity(mob);
        }

        private static BlockPos findSpawnPosition(ServerLevel level, ServerPlayer player, RandomSource random) {
            for (int attempt = 0; attempt < 8; attempt++) {
                double angle = random.nextDouble() * Math.PI * 2.0D;
                int distance = 16 + random.nextInt(17);
                int x = player.getBlockX() + (int) Math.round(Math.cos(angle) * distance);
                int z = player.getBlockZ() + (int) Math.round(Math.sin(angle) * distance);
                BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        new BlockPos(x, player.getBlockY(), z));

                if (!level.getBlockState(top).isAir()) continue;
                if (!level.getFluidState(top).isEmpty()) continue;
                if (!level.getBlockState(top.below()).blocksMotion()) continue;
                if (top.distSqr(player.blockPosition()) < 14.0D * 14.0D) continue;
                return top;
            }
            return null;
        }

        private static Monster createRandomMonster(ServerLevel level, RandomSource random) {
            return switch (random.nextInt(11)) {
                case 0 -> new Zombie(level);
                case 1 -> new Skeleton(level);
                case 2 -> new Spider(level);
                case 3 -> new Creeper(level);
                case 4 -> new Husk(level);
                case 5 -> new Stray(level);
                case 6 -> new Witch(level);
                case 7 -> new EnderMan(level);
                case 8 -> new Pillager(level);
                case 9 -> new Vindicator(level);
                default -> new Slime(level);
            };
        }

        @SubscribeEvent
        public static void onMobTick(LivingEvent.LivingTickEvent event) {
            if (!(event.getEntity() instanceof Mob mob) || mob.level().isClientSide()) return;
            if (!(mob.level() instanceof ServerLevel level)) return;

            // Mod-spawned enemies that survive a minute evolve, up to three stages.
            if (mob.getPersistentData().getBoolean("NightmareSwarmSpawned")
                    && !mob.getPersistentData().getBoolean("NightmareSwarmBoss") && mob.tickCount % 1200 == 0) {
                int stage = mob.getPersistentData().getInt("NightmareSwarmEvolution");
                if (stage < 3 && mob.isAlive()) {
                    stage++;
                    mob.getPersistentData().putInt("NightmareSwarmEvolution", stage);
                    AttributeInstance health = mob.getAttribute(Attributes.MAX_HEALTH);
                    if (health != null) {
                        health.setBaseValue(Math.min(health.getBaseValue() * 1.35D, 500.0D));
                        mob.setHealth((float) Math.min(health.getValue(), mob.getHealth() * 1.35D));
                    }
                    multiplyAttribute(mob, Attributes.ATTACK_DAMAGE, 1.35D, 120.0D);
                    addAttribute(mob, Attributes.ARMOR, 4.0D, 35.0D);
                    mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 60 * 10, Math.min(stage - 1, 2)));
                    mob.setCustomName(Component.literal("進化種・第" + stage + "段階：" + mob.getType().getDescription().getString())
                            .withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
                    mob.setCustomNameVisible(true);
                    level.sendParticles(ParticleTypes.POOF, mob.getX(), mob.getY() + 1.0D, mob.getZ(), 20, 0.7D, 0.7D, 0.7D, 0.08D);
                }
            }

            if (!mob.getPersistentData().getBoolean("NightmareSwarmBoss")) return;
            if (mob.tickCount % 8 == 0) {
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, mob.getX(), mob.getY() + mob.getBbHeight() * 0.55D,
                        mob.getZ(), 8, mob.getBbWidth() * 0.7D, mob.getBbHeight() * 0.45D,
                        mob.getBbWidth() * 0.7D, 0.015D);
                level.sendParticles(ParticleTypes.CRIMSON_SPORE, mob.getX(), mob.getY() + mob.getBbHeight() * 0.5D,
                        mob.getZ(), 5, mob.getBbWidth() * 0.8D, mob.getBbHeight() * 0.5D,
                        mob.getBbWidth() * 0.8D, 0.01D);
            }

            // Minecraft's native boss bar, visible to players within 64 blocks.
            ServerBossEvent bar = BOSS_BARS.computeIfAbsent(mob.getUUID(), id ->
                    new ServerBossEvent(mob.getDisplayName(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.PROGRESS));
            bar.setName(mob.getDisplayName());
            bar.setProgress(Math.max(0.0F, Math.min(1.0F, mob.getHealth() / Math.max(1.0F, mob.getMaxHealth()))));
            for (ServerPlayer player : level.players()) {
                if (player.distanceToSqr(mob) <= 64.0D * 64.0D) bar.addPlayer(player);
                else bar.removePlayer(player);
            }

            // Signature attacks: call three elite reinforcements every 10 seconds.
            if (mob.tickCount % 200 == 0 && mob.getTarget() instanceof LivingEntity target) {
                for (int i = 0; i < 3; i++) {
                    Monster minion = createRandomMonster(level, level.getRandom());
                    if (minion != null) {
                        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
                        minion.moveTo(mob.getX() + Math.cos(angle) * 2.5D, mob.getY(),
                                mob.getZ() + Math.sin(angle) * 2.5D, level.getRandom().nextFloat() * 360.0F, 0.0F);
                        minion.setTarget(target);
                        minion.getPersistentData().putBoolean("NightmareSwarmSpawned", true);
                        empowerElite(minion);
                        level.addFreshEntity(minion);
                    }
                }
                level.sendParticles(ParticleTypes.FLAME, mob.getX(), mob.getY() + 1.0D, mob.getZ(), 30, 1.0D, 1.0D, 1.0D, 0.05D);
            }
            // Lightning attack every 15 seconds if the boss has a target.
            if (mob.tickCount % 300 == 0 && mob.getTarget() instanceof LivingEntity target) {
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                if (bolt != null) {
                    bolt.moveTo(target.getX(), target.getY(), target.getZ());
                    level.addFreshEntity(bolt);
                }
            }
            // The boss enrages once below 50% health.
            if (mob.getHealth() <= mob.getMaxHealth() * 0.5F && !mob.getPersistentData().getBoolean("NightmareSwarmEnraged")) {
                mob.getPersistentData().putBoolean("NightmareSwarmEnraged", true);
                multiplyAttribute(mob, Attributes.ATTACK_DAMAGE, 1.5D, 200.0D);
                multiplyAttribute(mob, Attributes.MOVEMENT_SPEED, 1.25D, 1.0D);
                mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 60 * 30, 3));
                mob.setCustomName(Component.literal("怒り狂う・" + mob.getDisplayName().getString())
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
                level.sendParticles(ParticleTypes.EXPLOSION, mob.getX(), mob.getY() + mob.getBbHeight() * 0.5D,
                        mob.getZ(), 8, 1.0D, 1.0D, 1.0D, 0.0D);
            }
        }

        @SubscribeEvent
        public static void onMobDeath(LivingDeathEvent event) {
            LivingEntity entity = event.getEntity();
            if (entity.level().isClientSide()) return;
            ServerBossEvent bar = BOSS_BARS.remove(entity.getUUID());
            if (bar != null) bar.removeAllPlayers();
        }

        @SubscribeEvent
        public static void onNightmareDrops(LivingDropsEvent event) {
            LivingEntity entity = event.getEntity();
            if (entity.level().isClientSide() || !(entity.level() instanceof ServerLevel level)) return;
            boolean boss = entity.getPersistentData().getBoolean("NightmareSwarmBoss");
            boolean spawned = entity.getPersistentData().getBoolean("NightmareSwarmSpawned");
            if (!boss && !spawned) return;

            Item[] normalLoot = { Items.IRON_INGOT, Items.GOLD_INGOT, Items.EMERALD, Items.DIAMOND,
                    Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.EXPERIENCE_BOTTLE, Items.GOLDEN_CARROT,
                    Items.BLAZE_ROD, Items.OBSIDIAN };
            Item[] rareLoot = { Items.DIAMOND_BLOCK, Items.NETHERITE_INGOT, Items.ENCHANTED_GOLDEN_APPLE,
                    Items.TOTEM_OF_UNDYING, Items.NETHER_STAR, Items.ELYTRA, Items.TRIDENT, Items.BEACON,
                    Items.DRAGON_BREATH, Items.SHULKER_BOX };
            Item reward;
            if (boss) {
                reward = rareLoot[level.getRandom().nextInt(rareLoot.length)];
            } else {
                reward = normalLoot[level.getRandom().nextInt(normalLoot.length)];
                // Small chance for a regular enemy to give a rare reward too.
                if (level.getRandom().nextInt(30) == 0) reward = rareLoot[level.getRandom().nextInt(rareLoot.length)];
            }
            ItemEntity drop = new ItemEntity(level, entity.getX(), entity.getY() + 0.4D, entity.getZ(), new ItemStack(reward));
            event.getDrops().add(drop);
        }

        private static void empowerElite(Monster mob) {
            AttributeInstance health = mob.getAttribute(Attributes.MAX_HEALTH);
            if (health != null) {
                health.setBaseValue(Math.min(health.getBaseValue() * 4.0D, 300.0D));
                mob.setHealth((float) health.getValue());
            }
            multiplyAttribute(mob, Attributes.ATTACK_DAMAGE, 2.5D, 80.0D);
            addAttribute(mob, Attributes.ARMOR, 8.0D, 30.0D);
            mob.setCustomName(Component.literal("強化種：" + mob.getType().getDescription().getString())
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
            mob.setCustomNameVisible(true);
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 60 * 20, 0));
        }

        private static void empowerBoss(Monster mob, RandomSource random) {
            AttributeInstance health = mob.getAttribute(Attributes.MAX_HEALTH);
            if (health != null) {
                health.setBaseValue(800.0D + random.nextInt(1001));
                mob.setHealth((float) health.getValue());
            }
            double waveScale = Math.min(1.0D + waveCounter * 0.025D, 3.0D);
            setAttribute(mob, Attributes.ATTACK_DAMAGE, (50.0D + random.nextInt(51)) * waveScale);
            setAttribute(mob, Attributes.ARMOR, Math.min((20.0D + random.nextInt(16)) + waveCounter * 0.2D, 40.0D));
            setAttribute(mob, Attributes.FOLLOW_RANGE, 80.0D);
            multiplyAttribute(mob, Attributes.MOVEMENT_SPEED, 1.5D + Math.min(waveCounter * 0.002D, 0.5D), 0.8D);
            mob.setPersistenceRequired();
            mob.getPersistentData().putBoolean("NightmareSwarmBoss", true);
            // Visual upgrade: dark netherite armor, a gold accent, glow and a particle aura.
            mob.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
            mob.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.NETHERITE_CHESTPLATE));
            mob.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
            mob.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
            mob.setDropChance(EquipmentSlot.HEAD, 0.0F);
            mob.setDropChance(EquipmentSlot.CHEST, 0.0F);
            mob.setDropChance(EquipmentSlot.LEGS, 0.0F);
            mob.setDropChance(EquipmentSlot.FEET, 0.0F);
            mob.setCustomName(Component.literal(BOSS_NAMES[random.nextInt(BOSS_NAMES.length)])
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
            mob.setCustomNameVisible(true);
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 60 * 30, 2));
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 60 * 30, 1));
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 60 * 30, 1));
            mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 60 * 30, 0));
        }

        private static void multiplyAttribute(Mob mob, net.minecraft.world.entity.ai.attributes.Attribute attribute,
                                              double multiplier, double cap) {
            AttributeInstance instance = mob.getAttribute(attribute);
            if (instance != null) instance.setBaseValue(Math.min(instance.getBaseValue() * multiplier, cap));
        }

        private static void addAttribute(Mob mob, net.minecraft.world.entity.ai.attributes.Attribute attribute,
                                         double amount, double cap) {
            AttributeInstance instance = mob.getAttribute(attribute);
            if (instance != null) instance.setBaseValue(Math.min(instance.getBaseValue() + amount, cap));
        }

        private static void setAttribute(Mob mob, net.minecraft.world.entity.ai.attributes.Attribute attribute,
                                         double value) {
            AttributeInstance instance = mob.getAttribute(attribute);
            if (instance != null) instance.setBaseValue(value);
        }
    }
}
